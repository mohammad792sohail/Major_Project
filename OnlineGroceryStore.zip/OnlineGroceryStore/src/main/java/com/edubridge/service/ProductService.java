package com.edubridge.service;

import java.util.List;

import com.edubridge.model.Product;

public interface ProductService {
	public Product addProducts(Product product);
	public Product viewProductsById(int productId);
	public Product viewProductByName(String productName);
	public List<Product> viewAllProducts();
	public Product updateProductById(int productId,Product product);
	public Product deleteProductById(int productId);
	
}
