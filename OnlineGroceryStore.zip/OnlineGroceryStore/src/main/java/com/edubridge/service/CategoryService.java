package com.edubridge.service;

import java.util.List;

import com.edubridge.model.Category;

public interface CategoryService {
	public Category addCategory(Category category);
	public Category viewCategoryById(int categoryId);
	public List<Category> viewAllCategories();
	public Category updateCategoryById(int categoryId,Category category);
	public Category deleteCategory(int categoryId);
	//public Category getCategory(String categoryTitle);
}
