package com.edubridge.service;

import java.util.List;

import com.edubridge.model.Customer;

public interface CustomerService {
	public Customer customerLogin(Customer customer);
	public Customer getCustomerDetailsById(int customerid);
	public List<Customer> getAllCustomerDetails();
	public Customer savecustomer(Customer customer);
}
