package com.edubridge.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edubridge.model.Customer;
import com.edubridge.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService  {
	
	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public Customer customerLogin(Customer customer) {
		
		return customerRepository.findByCustomerUsernameAndCustomerPassword(customer.getCustomerUsername(), customer.getCustomerPassword());
	}

	@Override
	public Customer getCustomerDetailsById(int customerid) {
		
		return customerRepository.findById(customerid).get();
	}

	@Override
	public List<Customer> getAllCustomerDetails() {
		
		return customerRepository.findAll();
	}

	@Override
	public Customer savecustomer(Customer customer) {
		return customerRepository.save(customer);
	}

}
