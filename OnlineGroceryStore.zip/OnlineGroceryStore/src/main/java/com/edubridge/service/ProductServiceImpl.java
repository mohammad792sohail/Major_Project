package com.edubridge.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edubridge.model.Product;
import com.edubridge.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	ProductRepository productRepository;

	@Override
	public Product addProducts(Product product) {
		return productRepository.save(product);
	}

	@Override
	public Product viewProductsById(int productId) {
		return productRepository.findById(productId).get();
	}

	@Override
	public Product viewProductByName(String productName) {
		
		return productRepository.findByProductName(productName);
	}

	@Override
	public List<Product> viewAllProducts() {
		return productRepository.findAll();
	}

	@Override
	public Product updateProductById(int productId,Product product) {
		Product product1=productRepository.findByProductId(productId);
		if(product==null) {
			return null;
		}else {
			product1.setProductDescription(product.getProductDescription());
			product1.setProductDiscount(product.getProductDiscount());
			product1.setProductName(product.getProductName());
			product1.setProductPhoto(product.getProductPhoto());
			product1.setProductPrice(product1.getProductPrice());
			product1.setStock(product.getStock());
			product1.setCategory(product.getCategory());
		}
		return productRepository.save(product1);
	}

	@Override
	public Product deleteProductById(int productId) {
		if(productRepository.findById(productId)!=null) {
			 productRepository.deleteById(productId);
		}
		return null;
	}
}
