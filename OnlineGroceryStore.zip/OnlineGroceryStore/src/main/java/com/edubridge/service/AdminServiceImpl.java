package com.edubridge.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edubridge.model.Admin;
import com.edubridge.repository.AdminRepository;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private AdminRepository adminRepository;
	
	@Override
	public Admin adminLogin(Admin admin) {
		
		return adminRepository.findByAdminUsernameAndAdminPassword(admin.getAdminUsername(), admin.getAdminPassword());
	}
	@Override
	public Admin getAdminDetailsById(int adminId) {
		return adminRepository.findById(adminId).get();
		  
	}

	@Override
	public List<Admin> getAllAdminDetails() {
		return adminRepository.findAll() ;
	}

	@Override
	public Admin saveadmin(Admin admin) {
		
		return adminRepository.save(admin);
	}

}

