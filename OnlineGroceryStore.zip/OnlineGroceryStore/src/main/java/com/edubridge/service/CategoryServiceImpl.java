package com.edubridge.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.edubridge.model.Category;
import com.edubridge.repository.CategoryRepository;

@Service
public class CategoryServiceImpl implements CategoryService {

	@Autowired
	private CategoryRepository categoryRepository;

	@Override
	public Category addCategory(Category category) {

		return categoryRepository.save(category);
	}
	
	@Override
	public Category viewCategoryById(int categoryId) {

		return categoryRepository.findById(categoryId).get();
	}

	@Override
	public List<Category> viewAllCategories() {

		return categoryRepository.findAll();
	}

	public Category updateCategoryById(int categoryId, Category category) {
		Category category1 = categoryRepository.findByCategoryId(categoryId);
		if (category == null) {
			return null;
		} else {
			category1.setCategoryTitle(category.getCategoryTitle());
			category1.setCategoryDescription(category.getCategoryDescription());
		}
		return categoryRepository.save(category1);
	}

	@Override
	public Category deleteCategory(int categoryId) {
		if(categoryRepository.findById(categoryId) != null) {
			categoryRepository.deleteById(categoryId);
		}
		return null;
	}

//	@Override
//	public Category getCategory(String categoryTitle) {
//		// TODO Auto-generated method stub
//		return categoryRepository.findbyCategoryTitle(categoryTitle);
//	}

}
