package com.edubridge.service;

import java.util.List;

import com.edubridge.model.Admin;


public interface AdminService {
	public Admin adminLogin(Admin admin);
	public Admin getAdminDetailsById(int adminId);
	public List<Admin> getAllAdminDetails();
	public Admin saveadmin(Admin admin);
}
