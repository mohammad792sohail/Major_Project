package com.edubridge.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.edubridge.model.Admin;
import com.edubridge.model.Category;
import com.edubridge.model.Customer;
import com.edubridge.model.Product;
import com.edubridge.service.AdminService;
import com.edubridge.service.CategoryService;
import com.edubridge.service.CustomerService;
import com.edubridge.service.ProductService;

@RestController
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private AdminService adminService;

	@Autowired
	private CustomerService customerservice;
	
	@Autowired
	private CategoryService categoryService;
	
	@Autowired
	private ProductService productService;

	//admin is registering
	@PostMapping
	public ResponseEntity<Admin> register(@RequestBody Admin admin) {
		return new ResponseEntity<Admin>(adminService.saveadmin(admin), HttpStatus.CREATED);
	}

	//admin loggin in
	@PostMapping("/adminlogin")
	public ResponseEntity<Admin> adminLogin(@RequestBody Admin admin) {
		return new ResponseEntity<Admin>(adminService.adminLogin(admin), HttpStatus.FOUND);

	}

	//getting admin details by id
	@GetMapping("{adminId}")
	public Admin getAdminDetailsById(@PathVariable("adminId") int adminId) {
		return adminService.getAdminDetailsById(adminId);

	}
	//getting all admin details
	@GetMapping()
	public List<Admin> getAllAdminDetails() {
		return adminService.getAllAdminDetails();
	}
	
	
	//admin getting the details of the customer based on Id
	@GetMapping("customer/{customerId}")
	public Customer getCustomerDetailsById(@PathVariable("customerId") int customerId) {
		return customerservice.getCustomerDetailsById(customerId);
	}

	//Admin getting all the details of the customer
	@GetMapping("customer")
	public List<Customer> getAllCustomerDetails() {
		return customerservice.getAllCustomerDetails();

	}
	
	//admin is viewing the categories
	@GetMapping("category")
	public List<Category> viewcategory() {
		return categoryService.viewAllCategories();
	}
	
	//admin is adding the categories
	@PostMapping("category")
	public ResponseEntity<Category> addCategory(@RequestBody Category category){
		return new ResponseEntity<Category>(categoryService.addCategory(category),HttpStatus.CREATED);
	}
	
	//admin is viewing the categories based on the id;
	@GetMapping("category/{categoryId}")
	public ResponseEntity<Category> viewByCategoryId(@PathVariable("categoryId") int categoryId){
		return new ResponseEntity<Category> (categoryService.viewCategoryById(categoryId),HttpStatus.ACCEPTED);
	}
	
	
	
	//admin is updating the categories based on the id
	@PutMapping("category/{categoryId}")
	public ResponseEntity <Category> updateCategoryById(@PathVariable("categoryId") int categoryId,@RequestBody Category category){
		return new ResponseEntity<Category> (categoryService.updateCategoryById(categoryId,category),HttpStatus.ACCEPTED);
	}
	
	//admin deleting the categories
	@DeleteMapping("category/{categoryId}")
	public Category deleteCategoryById(@PathVariable("categoryId") int categoryId) {
		return categoryService.deleteCategory(categoryId);
	}
	
	//admin is viewing the products by id
	@GetMapping("products/{productId}")
	public ResponseEntity<Product> viewProductById(@PathVariable("productId") int productId){
		return new ResponseEntity<Product> (productService.viewProductsById(productId),HttpStatus.ACCEPTED);
	}
	
	//admin is viewing the products by Name
	@GetMapping("products/{productName}")
	public ResponseEntity<Product> viewProductByName(@PathVariable("productName") String productName){
		return new ResponseEntity<Product> (productService.viewProductByName(productName),HttpStatus.ACCEPTED);
	}
	
	//admin is viewing all the products
	@GetMapping("products")
	public List<Product> viewAllProducts(){
		return productService.viewAllProducts();
	}
	
	//admin is adding the products
	@PostMapping(value="/products")
	public ResponseEntity<Product> addProducts(@RequestBody Product product){
		return new ResponseEntity<Product> (productService.addProducts(product),HttpStatus.ACCEPTED);
	}
	
	//admin has to update the products based on the 
	@PutMapping("products/{productId}")
	public ResponseEntity <Product> updateProductById(@PathVariable("productId") int productId,@RequestBody Product product){
		return new ResponseEntity<Product> (productService.updateProductById(productId, product),HttpStatus.ACCEPTED);
	}
	
	//admin is deleting the product
	@DeleteMapping("products/{productId}")
	public Product deleteById(@PathVariable("productId") int productId) {
		return productService.deleteProductById(productId);
	}

}
