package com.edubridge.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.edubridge.model.Category;
import com.edubridge.service.CategoryService;

@RestController
@RequestMapping("/category")
public class CategoryController {

	@Autowired
	private CategoryService categoryService;
	
	//add 
	@PostMapping
	public ResponseEntity<Category> addCategory(@RequestBody Category category){
		return new ResponseEntity<Category>(categoryService.addCategory(category),HttpStatus.CREATED);
	}
	
	//getbyid
	@GetMapping("{categoryId}")
	public ResponseEntity <Category> viewCategoryById(@PathVariable("categoryId") int categoryId){
		return new ResponseEntity<Category> (categoryService.viewCategoryById(categoryId),HttpStatus.FOUND);
	}
	
	
	
	//get all
	@GetMapping()
	public List<Category> viewAllCategories(){
		return categoryService.viewAllCategories();
	}
	
	//updating
	@PutMapping("{categoryId}")
	public ResponseEntity <Category> updateCategoryById(@PathVariable("categoryId") int categoryId,@RequestBody Category category){
		return new ResponseEntity<Category> (categoryService.updateCategoryById(categoryId,category),HttpStatus.ACCEPTED);
	}
	
	//deleting
	@DeleteMapping("{categoryId}")
	public Category deleteCategoryById(@PathVariable("categoryId") int categoryId) {
		return categoryService.deleteCategory(categoryId);
		
	}

	
	 
	
	
	
}
