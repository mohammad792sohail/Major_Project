package com.edubridge.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.edubridge.model.Category;
import com.edubridge.model.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Integer>{

	Product save(Product product);
	Product findByProductName(String productName);
	Product save(int productId);
	Product findByProductId(int productId);

}
